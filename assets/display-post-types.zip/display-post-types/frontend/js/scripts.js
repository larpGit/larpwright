import DisplayPostTypes from './partials/index';
new DisplayPostTypes();